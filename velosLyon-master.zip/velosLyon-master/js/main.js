let slider = new Slider();
let canvas = new Canvas();
let map = new Map("https://api.jcdecaux.com/vls/v1/stations?contract=Lyon&apiKey=41dd5bacc66f902914ec4bc2c840ef00bcd1b57e");
let timer = new Timer();




